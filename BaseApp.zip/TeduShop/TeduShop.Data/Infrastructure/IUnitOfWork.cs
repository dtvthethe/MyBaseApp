﻿namespace TeduShop.Data.Infrastructure
{
    public interface IUnitOfWork
    {
        void Commit();
    }
}