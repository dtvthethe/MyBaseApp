﻿(function () {
    angular.module('tedushop.common',
        ['ui.router',
         'ngBootbox',
         'ngCkeditor',
         'checklist-model',
         'chart.js',
         'LocalStorageModule',
         'ui.select',
         'ngSanitize'
        ])
})();