﻿(function (app) {
    app.controller('homeController', homeController);

    function homeController() {

    }
})(angular.module('tedushop'));